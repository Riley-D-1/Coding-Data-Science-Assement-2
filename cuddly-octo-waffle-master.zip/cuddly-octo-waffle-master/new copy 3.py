#Imports
import requests
import pandas as pd
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime
import pytz
# All imports (yes there is a lot, but they all play a role )
# Variable setting and Flask initialisasation
# Draw the Api key - TO DO 

app = Flask(__name__)
#function defining
def get_coins(currency):
    url = 'https://api.coingecko.com/api/v3/coins/markets'
    params = {
        'vs_currency': currency,
        'order': 'market_cap_desc',
        'per_page': 20,
        'page': 1,
    }
    response = requests.get(url, params=params)
    if response.status_code != 200:
        return "Error fetching data from CoinGecko", 500
        #Work out some code that will drag the data from the CSV files
    return response.json()

#flask routing (yes its janky and unoptimsed leave me alone)
@app.route('/')
def home():
    items = get_coins("USD")
    return render_template('index.html', items=items)

@app.route('/info')
def info():
    return render_template('info.html')

@app.route('/plot', methods=['POST'])
def plot():
    current_time = datetime.now(pytz.timezone('Australia/Sydney'))
    time_data=(f"{current_time.time()}_{current_time.date()}")
    csv_save_data= time_data.replace(":","_")
    # Retrieve selected coins and number of days from the form
    selected_coins = request.form.getlist('coins')
    days = request.form.get('days', '30')
    currency = "USD"
    #currency = request.form.get()
    # Default to 30 days if no value is provided
    # Redirecter in case you try to glitch the application 
    if not selected_coins:
        return redirect(url_for('home'))
    # remove me below! this is a debugging statement so i can see it works and prints coins - so it recieves data but i now need to resturcture 
    for selected_coin in selected_coins:
        print(selected_coin)

    if 'prices' not in get_coins(currency):
        return "Invalid data format received from CoinGecko", 500

    # Extract price data
    prices = get_coins(currency)['prices']

    # Convert to DataFrame
    df = pd.DataFrame(prices, columns=['timestamp', 'price'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.to_csv('data-saves/'+csv_save_data + '.csv', header=None, index=False, names=['Coin name','Timestamp', 'Coin Vaule', ])

    coin_id = ""
    for coin in selected_coins:
        coin_id+= f"{coin}"
        if coin_id != "" or selected_coin =="":
            coid_id+= "+"

    # Plot data
    plt.figure(figsize=(10, 5))
    df.plot(
        kind='line',
        x='timestamp',
        y='price',
        color='blue',
        alpha=0.9,
        title=f'{coin_id.capitalize()} Price Over Last {days} Days'
    )
    # You know funnily this pulls an error and it says its unlikely to work (becuase its outside the main loop (not really but matplotlib thinks that)) but it hasnt failed yet soooooo?
    # Saves plot to a file in static (flask checks here )
    plot_path = 'static/data.jpg'
    plt.savefig(plot_path)
    plt.close()
    return render_template('result.html', coin_id=coin_id, days=days, plot_path=plot_path, items=get_coins())
#Main Loop 
if __name__ == '__main__':
    app.run(debug=True)


#To do 
#CSV
#Info page